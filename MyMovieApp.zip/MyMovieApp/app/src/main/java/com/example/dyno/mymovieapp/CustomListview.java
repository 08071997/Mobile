package com.example.dyno.mymovieapp;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class CustomListview extends ArrayAdapter<String>{

private String[] movietitle;
private String[] synopsis;
private Integer[] imgid;
private Activity context;
    public CustomListview(Activity context, String[] movietitle,String[] synopsis,Integer[] imgid) {
        super(context, R.layout.layout, movietitle);

        this.context=context;
        this.movietitle=movietitle;
        this.synopsis=synopsis;
        this.imgid=imgid;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View r=convertView;
        ViewHolder viewHolder=null;
        if(r==null)
        {
            LayoutInflater layoutInflater=context.getLayoutInflater();
            r=layoutInflater.inflate(R.layout.layout,null,true);
            viewHolder=new ViewHolder(r);
            r.setTag(viewHolder);
        }
        else {
            viewHolder= (ViewHolder) r.getTag();
        }
        viewHolder.ivw.setImageResource(imgid[position]);
        viewHolder.tvw1.setText(movietitle[position]);
        viewHolder.tvw2.setText(synopsis[position]);
        return r;


    }
    class ViewHolder
    {
        TextView tvw1;
        TextView tvw2;
        ImageView ivw;
        ViewHolder(View v)
        {
            tvw1= (TextView) v.findViewById(R.id.movietitle);
            tvw2= (TextView) v.findViewById(R.id.synopsis);
            ivw= (ImageView) v.findViewById(R.id.imageView);
        }

    }
}
